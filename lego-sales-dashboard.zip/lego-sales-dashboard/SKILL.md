---
name: lego-sales-dashboard
description: 乐高苏中区域销售看板生成技能。当用户说"出看板"、"生成看板"、"更新看板"、"销售看板"，或需要从销售订单数据生成可视化HTML看板时触发。覆盖数据清洗、指标计算、HTML生成、云端部署全流程。适用于乐高零售苏中区域7家门店的每日销售数据可视化。
agent_created: true
---

# 乐高苏中区域销售看板生成

## 概述

为乐高零售苏中区域城市经理生成每日销售看板HTML页面。从原始销售订单数据（CSV/XLSX）出发，经过数据清洗、指标计算、可视化渲染，最终生成可直接在微信中打开的云端看板链接。

用户日常操作：导入今日销售订单文件 → 说"出看板" → 自动生成并部署看板。

## 触发条件

当用户说以下任一内容时触发：
- "出看板"、"生成看板"、"更新看板"
- "看看今天销售"、"销售数据"
- 任何需要从销售订单生成可视化看板的请求

## 文件位置规则

| 文件类型 | 位置 | 说明 |
|---------|------|------|
| 今日销售订单 | `~/Desktop/` 下的xlsx或csv | 用户刚导入的，文件名含"销售订单明细查询" |
| 历史销售订单 | `~/Downloads/` 下的CSV | 包含本月1号到昨日的数据，可能有多个CSV |
| 门店指标+同期 | `~/Desktop/报表/7月指标同期.xlsx` | 固定路径，含门店月指标、日指标、去年同期数据 |
| 导购指标 | 企微缓存目录 | `~/Library/Containers/com.tencent.WeWorkMac/Data/Documents/Profiles/*/Caches/Files/` 下，文件名"苏中区域7月员工指标分解.xlsx" |
| 长尾款SKU | 企微缓存目录 | 同上目录，文件名"长尾款sku明细.xlsx" |

### 查找企微缓存文件的方法

导购指标和长尾款SKU文件路径每次可能变化，需用以下命令查找：

```bash
find ~/Library/Containers/com.tencent.WeWorkMac/Data/Documents/Profiles/*/Caches/Files/ -name "苏中区域*员工指标*.xlsx" 2>/dev/null
find ~/Library/Containers/com.tencent.WeWorkMac/Data/Documents/Profiles/*/Caches/Files/ -name "长尾款sku*.xlsx" 2>/dev/null
```

## 工作流程

### 第1步：定位文件

1. 在 `~/Desktop/` 找到最新的销售订单xlsx文件（文件名含"销售订单明细查询"）
2. 在 `~/Downloads/` 找到所有历史CSV文件（文件名含"销售订单明细查询"）
3. 确认 `~/Desktop/报表/7月指标同期.xlsx` 存在
4. 用上述find命令查找导购指标和长尾款SKU文件

### 第2步：确定报告日期

从今日xlsx文件内容中读取最大销售日期作为报告日。例如数据最大日期为7月13日，则：
- REPORT_DATE = '7月13日'
- is_today条件 = `all_df['销售日期_dt'].dt.day == 13`
- REPORT_DAY_INDEX = 日期 + 1（7月1日=col2, 7月13日=col14）

### 第3步：更新脚本配置

将 `scripts/generate_dashboard.py` 复制到项目目录，修改以下配置项：

```python
# 必须更新的配置
TODAY_XLSX = '<今日xlsx完整路径>'
HIST_CSVS = ['<历史CSV路径1>', '<历史CSV路径2>', ...]
GUIDE_XLSX = '<导购指标xlsx路径>'
LT_SKU_XLSX = '<长尾款SKU xlsx路径>'
REPORT_DATE = '7月13日'  # 报告日期文本
REPORT_DAY_INDEX = 14     # 报告日对应的列索引（7.1=col2, 7.13=col14）
# is_today 条件中的日期数字
all_df['is_today'] = all_df['销售日期_dt'].dt.day == 13  # 改为实际日期
```

以下配置保持不变：
```python
# 固定配置（不需要修改）
STORE_ORDER = ['扬州万象汇', '扬州京华城', '扬州江都金鹰', '泰州万象城', '宿迁宝龙', '淮安新亚', '淮安万象城']
WK28_START_DATE = '2026-07-06'  # WK28基准日
TARGET_XLSX = '<用户Desktop>/报表/7月指标同期.xlsx'
OUTPUT_HTML = '<项目目录>/outputs/dashboard_latest.html'
OUTPUT_MOBILE_HTML = '<项目目录>/outputs/dashboard_latest_mobile.html'
OUTPUT_JSON = '<项目目录>/outputs/dashboard_latest.json'
# WK_NUM 自动推算，无需手动改
```

### 第4步：运行脚本

```bash
cd <项目目录>
/Users/a123/.workbuddy/binaries/python/envs/default/bin/python generate_dashboard.py
```

脚本依赖 pandas 和 openpyxl，确保已安装：
```bash
/Users/a123/.workbuddy/binaries/python/envs/default/bin/pip install pandas openpyxl
```

### 第5步：云端部署

使用 cloudstudio-deploy 部署 outputs 目录：

```
workbuddy_cloudstudio_deploy(directory: "<项目目录>/outputs")
```

云端固定链接：`https://e402b0b510e04617bba5890270221fef.app.codebuddy.work`
每次部署覆盖同一个workspace，链接不变。

### 第6步：展示结果

用 present_files 展示云端固定链接给用户，微信可直接打开。

## 脚本说明

`scripts/generate_dashboard.py` 是核心脚本，一步完成：
1. 读取+合并订单数据（历史CSV + 今日XLSX）
2. 数据清洗（过滤赠品/样品/非当月、门店映射、金额转float）
3. WK周自动推算
4. 读取指标数据（门店月/日指标、同期数据）
5. 读取长尾款SKU + 导购指标
6. 计算各维度数据（区域KPI、门店KPI、长尾款、导购、WOS、即时零售、重点SKU）
7. 生成JSON数据文件
8. 生成HTML看板（含KPI卡片、各模块表格、Chart.js图表）
9. 生成移动端版本 + 复制index.html

## 详细规则参考

所有看板格式规则、数据口径、配色方案、导购映射规则等详见：
`references/dashboard_rules.md`

在更新或调试看板时，务必参考该文件确保格式一致。

## 常见注意事项

1. **不要按单号去重**：同一单号有多行产品，去重会丢失数据
2. **乐高编号类型匹配**：SKU文件为int，订单CSV为float，需统一为int字符串
3. **淮安万象城无同期数据**：同比计算排除该店，显示N/A
4. **导购姓名映射**：长期兼职-前缀去掉，支援销售需合并到本体
5. **REPORT_DAY_INDEX计算**：7月1日=col2，7月N日=col(N+1)
6. **重点SKU易混淆编号**：77259才是奥迪F1赛车R26，77252是APXGP赛车
7. **长尾款指标**：不再从文件读取，改为销售指标 x 12.5%自动计算
