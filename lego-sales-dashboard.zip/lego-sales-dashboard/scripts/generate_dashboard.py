#!/usr/bin/env python3
"""
苏中区域7月8日销售看板 —— 完整数据计算 + HTML生成
一步到位，从原始订单数据到最终HTML看板
"""
import pandas as pd
import json
import os
from datetime import datetime

# ============================================================
# 配置
# ============================================================
STORE_ORDER = ['扬州万象汇', '扬州京华城', '扬州江都金鹰', '泰州万象城', '宿迁宝龙', '淮安新亚', '淮安万象城']
STORE_CODE_MAP = {
    'LCS133-LW': '扬州万象汇', 'LCS275-LW': '扬州京华城', 'LCS364-LW': '扬州江都金鹰',
    'LCS0632-LW': '泰州万象城', 'LCS249-LW': '宿迁宝龙', 'LCS305-LW': '淮安新亚',
    'LCS0420-LW': '淮安万象城'
}
NEW_STORE = '淮安万象城'  # 无同期数据
WK28_START_DATE = '2026-07-06'  # WK28周一基准日
REPORT_DATE = '7月13日'
# WK编号自动计算：从数据日期推算当前周
WK28_BASE = pd.Timestamp(WK28_START_DATE)

# 文件路径
HIST_CSVS = [
    '/Users/a123/Downloads/销售订单明细查询(8b96982b-cf07-4b9c-8bea-9c242dc98427)-No.232064.csv',
    '/Users/a123/Downloads/销售订单明细查询(4a88ab7e-721f-437d-b969-b8954210e4e7)-No.232149.csv',
    '/Users/a123/Downloads/销售订单明细查询(7a6c0958-e2bc-41dd-a5c1-897b9bd5ae56)-No.232222.csv',
    '/Users/a123/Downloads/销售订单明细查询(f4c2f2bf-8b39-4a8a-a7da-12033c2eb631)-No.232269.csv',
]
TODAY_XLSX = '/Users/a123/Desktop/销售订单明细查询(f60cac37-5266-4d84-ad0e-efe0e94cd46d)-No.232431.xlsx'
TARGET_XLSX = '/Users/a123/Desktop/。/7月指标同期.xlsx'
GUIDE_XLSX = '/Users/a123/Library/Containers/com.tencent.WeWorkMac/Data/Documents/Profiles/3DF88FB58DC0D4D454CF52373FF5D0A4/Caches/Files/2026-07/1756c3b49fab5f84306db0c87c8f31f2/苏中区域7月员工指标分解.xlsx'
LT_SKU_XLSX = '/Users/a123/Library/Containers/com.tencent.WeWorkMac/Data/Documents/Profiles/3DF88FB58DC0D4D454CF52373FF5D0A4/Caches/Files/2026-07/94e3835ae7d46f94196133121918cb3c/长尾款sku明细.xlsx'
OUTPUT_HTML = '/Users/a123/WorkBuddy/Claw/outputs/dashboard_latest.html'
OUTPUT_MOBILE_HTML = '/Users/a123/WorkBuddy/Claw/outputs/dashboard_latest_mobile.html'
OUTPUT_JSON = '/Users/a123/WorkBuddy/Claw/outputs/dashboard_latest.json'

# 重点SKU开单跟踪
KEY_SKUS = {
    '40648': '摇钱树',
    '77259': '奥迪F1赛车',
    '60500': '运输面包车',
    '40864': '财神爷',
    '854328': '小飞象',
    '854327': '辛巴',
    '854331': '龙裔圣武士',
}
KEYCHAIN_SKUS = {}  # 已合并到KEY_SKUS

# ============================================================
# 1. 读取+清洗订单数据
# ============================================================
print("1. 读取订单数据...")
# 自动判断今日文件是csv还是xlsx
if TODAY_XLSX.endswith('.csv'):
    today_df = pd.read_csv(TODAY_XLSX, low_memory=False)
else:
    today_df = pd.read_excel(TODAY_XLSX)
# 如果有历史CSV则合并，否则直接用今日文件
if HIST_CSVS:
    hist_dfs = [pd.read_csv(f, low_memory=False) for f in HIST_CSVS]
    hist_df = pd.concat(hist_dfs, ignore_index=True)
    all_df = pd.concat([hist_df, today_df], ignore_index=True)
else:
    all_df = today_df.copy()
print(f"   合并后总行数: {len(all_df)}")

# 日期列名统一
all_df['销售日期_dt'] = pd.to_datetime(all_df['销售日期'])

# 只取7月数据
all_df = all_df[all_df['销售日期_dt'].dt.month == 7]

# 排除赠品和样品
all_df = all_df[all_df['是否赠品'] != '是']
all_df = all_df[~all_df['商品名称'].str.contains('样品', na=False)]

# 门店名映射（用发货店仓编码）
all_df['门店名'] = all_df['发货店仓编码'].map(STORE_CODE_MAP)
all_df = all_df[all_df['门店名'].notna()]

# 结算金额确保是float
all_df['结算金额'] = all_df['结算金额'].astype(float)

# 数据清洗后统一乐高编号格式
all_df['乐高编号_str'] = all_df['乐高编号'].apply(lambda v: str(int(v)) if pd.notna(v) and v == int(v) else str(v) if pd.notna(v) else '')

# 日期标记 + WK周自动推算
all_df['is_today'] = all_df['销售日期_dt'].dt.day == 13
# 从当日数据推算当前WK编号和周起始日
max_date = all_df['销售日期_dt'].max()
weeks_since_wk28 = (max_date - WK28_BASE).days // 7
WK_NUM_INT = 28 + weeks_since_wk28
WK_NUM = f'WK{WK_NUM_INT}'
WK_START = WK28_BASE + pd.Timedelta(weeks=weeks_since_wk28)
print(f"   当前周: {WK_NUM}, 周起始: {WK_START.strftime('%m.%d')}, 报告日: {max_date.strftime('%m.%d')}")
all_df['is_current_wk'] = (all_df['销售日期_dt'] >= WK_START) & (all_df['销售日期_dt'] <= max_date)

today_count = len(all_df[all_df['is_today']])
print(f"   清洗后行数: {len(all_df)}, 今日行数: {today_count}")

# ============================================================
# 2. 读取指标数据
# ============================================================
print("2. 读取指标数据...")
target_df = pd.read_excel(TARGET_XLSX, header=None)

# 门店月指标 + 每日指标 (rows 2-9)
# col2=7.1, col3=7.2, ..., col12=7.11
REPORT_DAY_INDEX = 14  # 7.13 = col14

store_targets = {}
for i in range(2, 10):
    name = str(target_df.iloc[i, 0]).strip()
    month_t = target_df.iloc[i, 1]
    daily_t = target_df.iloc[i, REPORT_DAY_INDEX]
    if name in STORE_ORDER:
        store_targets[name] = {'month': float(month_t), 'daily': float(daily_t)}
    elif name == '苏中区域':
        region_month_target = float(month_t)
        region_daily_target = float(daily_t)

# 长尾款指标 = 销售指标 × 12.5%
lt_targets = {}
for name, t in store_targets.items():
    lt_targets[name] = {'month': round(t['month'] * 0.125, 2), 'daily': round(t['daily'] * 0.125, 2)}
region_lt_month_target = round(region_month_target * 0.125, 2)
region_lt_daily_target = round(region_daily_target * 0.125, 2)

# 同期数据 (rows 13-20, row 12=header)
# col2=7.1, col3=7.2, ..., col12=7.11
# 日同期 = col(REPORT_DAY_INDEX)
# 月累计同期 = sum(col2 : col(REPORT_DAY_INDEX))
yoy_data = {}
for i in range(13, 21):
    name = str(target_df.iloc[i, 0]).strip()
    if not name or name == '门店':
        continue
    if name in STORE_ORDER and name != NEW_STORE:
        day_values = []
        for j in range(2, REPORT_DAY_INDEX + 1):
            v = target_df.iloc[i, j]
            if pd.notna(v) and v != '':
                day_values.append(float(v))
        day_yoy = day_values[-1] if day_values else 0
        month_cum = sum(day_values)
        yoy_data[name] = {
            'day': day_yoy,
            'month_cum': month_cum
        }
    elif name == '苏中区域':
        day_values = []
        for j in range(2, REPORT_DAY_INDEX + 1):
            v = target_df.iloc[i, j]
            if pd.notna(v) and v != '':
                day_values.append(float(v))
        day_yoy = day_values[-1] if day_values else 0
        month_cum = sum(day_values)
        region_yoy = {
            'day': day_yoy,
            'month_cum': month_cum
        }

print(f"   门店月指标: {store_targets}")
print(f"   区域月指标: {region_month_target}, 日指标: {region_daily_target}")
print(f"   长尾款月指标(12.5%): {lt_targets}")
print(f"   同期日同比: {[(k, v['day']) for k, v in yoy_data.items()]}")

# ============================================================
# 3. 读取长尾款SKU
# ============================================================
print("3. 读取长尾款SKU明细...")
lt_sku_df = pd.read_excel(LT_SKU_XLSX)
# 乐高编号统一为int字符串格式（避免float/int类型不匹配）
lt_skus = set()
for v in lt_sku_df['乐高编号']:
    try:
        lt_skus.add(str(int(v)))
    except (ValueError, TypeError):
        lt_skus.add(str(v).strip())
print(f"   长尾款SKU数: {len(lt_skus)}")

# ============================================================
# 4. 读取导购指标
# ============================================================
print("4. 读取导购指标...")
guide_df = pd.read_excel(GUIDE_XLSX)

# 导购姓名映射规则
def normalize_guide_name(name):
    if name is None or str(name).strip() == '':
        return None
    name = str(name).strip()
    # 去掉"长期兼职-"前缀
    if name.startswith('长期兼职-'):
        name = name[len('长期兼职-'):]
    # 映射支援导购
    if name == '扬万支援销售':
        name = '李婷1'
    if name == '泰州万象城-支援2' or name == '泰州万象城支援2':
        name = '黄小莉1'
    # 李婷本体→李婷1（合并指标）
    if name == '李婷':
        name = '李婷1'
    # 黄小莉本体→黄小莉1（合并指标）
    if name == '黄小莉':
        name = '黄小莉1'
    return name

def normalize_store_name(name):
    if name is None:
        return None
    name = str(name).strip()
    variants = {
        '扬州万象汇店': '扬州万象汇',
        '扬州京华城店': '扬州京华城',
        '扬州江都金鹰店': '扬州江都金鹰',
        '泰州万象城': '泰州万象城',
        '宿迁宝龙店': '宿迁宝龙',
        '淮安新亚广场店': '淮安新亚',
        '淮安万象城店': '淮安万象城',
    }
    return variants.get(name, name)

guide_info = {}
for _, row in guide_df.iterrows():
    gname = normalize_guide_name(row.get('姓名', row.get('导购姓名', '')))
    if gname is None:
        continue
    store = normalize_store_name(row.get('门店', row.get('门店名称', '')))
    if store not in STORE_ORDER:
        continue
    title = str(row.get('职务', row.get('職务', ''))).strip()
    target = float(row.get('员工个人指标', row.get('个人指标', 0)))
    if gname in guide_info:
        # 合并指标（如李婷1出现两次）
        guide_info[gname]['target'] += target
    else:
        guide_info[gname] = {'store': store, 'title': title, 'target': target}

print(f"   有效导购数: {len(guide_info)}")

# ============================================================
# 5. 计算各维度数据
# ============================================================
print("5. 计算各维度数据...")

# --- 区域核心KPI ---
today_all = all_df[all_df['is_today']]
region_day_amt = today_all['结算金额'].sum()
region_month_amt = all_df['结算金额'].sum()
region_day_rate = region_day_amt / region_daily_target * 100
region_month_rate = region_month_amt / region_month_target * 100

# 区域长尾款汇总
region_lt_day_amt = today_all[today_all['乐高编号_str'].isin(lt_skus)]['结算金额'].sum()
region_lt_month_amt = all_df[all_df['乐高编号_str'].isin(lt_skus)]['结算金额'].sum()
# 件数
region_lt_day_qty = int(today_all[(today_all['乐高编号_str'].isin(lt_skus)) & (today_all['结算金额'] > 0)]['数量'].sum()) if len(today_all[(today_all['乐高编号_str'].isin(lt_skus)) & (today_all['结算金额'] > 0)]) > 0 else 0
region_lt_month_qty = int(all_df[(all_df['乐高编号_str'].isin(lt_skus)) & (all_df['结算金额'] > 0)]['数量'].sum()) if len(all_df[(all_df['乐高编号_str'].isin(lt_skus)) & (all_df['结算金额'] > 0)]) > 0 else 0
region_lt_day_rate = region_lt_day_amt / region_lt_daily_target * 100
region_lt_month_rate = region_lt_month_amt / region_lt_month_target * 100

# 日同比（排除淮安万象城）
today_no_new = today_all[today_all['门店名'] != NEW_STORE]
yoy_day_sum = sum(yoy_data[s]['day'] for s in yoy_data if s != NEW_STORE)
region_day_yoy = (today_no_new['结算金额'].sum() - yoy_day_sum) / yoy_day_sum * 100

# 月同比（排除淮安万象城）
month_no_new = all_df[all_df['门店名'] != NEW_STORE]
yoy_month_sum = sum(yoy_data[s]['month_cum'] for s in yoy_data if s != NEW_STORE)
region_month_yoy = (month_no_new['结算金额'].sum() - yoy_month_sum) / yoy_month_sum * 100

print(f"   区域日销售: ¥{region_day_amt:.0f}, 月累计: ¥{region_month_amt:.0f}")
print(f"   日完成率: {region_day_rate:.1f}%, 月完成率: {region_month_rate:.1f}%")
print(f"   日同比: {region_day_yoy:.1f}%, 月同比: {region_month_yoy:.1f}%")

# --- 门店KPI ---
store_data = {}
for store in STORE_ORDER:
    s_all = all_df[all_df['门店名'] == store]
    s_today = s_all[s_all['is_today']]
    s_wk28 = s_all[s_all['is_current_wk']]
    
    day_amt = s_today['结算金额'].sum()
    month_amt = s_all['结算金额'].sum()
    wk28_amt = s_wk28['结算金额'].sum()
    
    day_target = store_targets[store]['daily']
    month_target = store_targets[store]['month']
    day_rate = day_amt / day_target * 100
    month_rate = month_amt / month_target * 100
    
    # 连带率 = 正单总数量 / 正单总单数
    pos_today = s_today[s_today['结算金额'] > 0]
    day_cnt = pos_today['单号'].nunique() if len(pos_today) > 0 else 0
    day_qty = len(pos_today) if len(pos_today) > 0 else 0
    day_jd = day_qty / day_cnt if day_cnt > 0 else 0
    
    # 客单价 = 正单总金额 / 正单总单数
    day_kdj = pos_today['结算金额'].sum() / day_cnt if day_cnt > 0 else 0
    
    # 日同比
    if store != NEW_STORE:
        yoy_d = yoy_data[store]['day']
        day_yoy = (day_amt - yoy_d) / yoy_d * 100 if yoy_d != 0 else 0
    else:
        day_yoy = None
    
    # 月同比
    if store != NEW_STORE:
        yoy_m = yoy_data[store]['month_cum']
        month_yoy = (month_amt - yoy_m) / yoy_m * 100 if yoy_m != 0 else 0
    else:
        month_yoy = None
    
    # 长尾款（79SKU匹配）
    s_today_lt = s_today[s_today['乐高编号_str'].isin(lt_skus)]
    s_all_lt = s_all[s_all['乐高编号_str'].isin(lt_skus)]
    day_lt_amt = s_today_lt['结算金额'].sum()
    month_lt_amt = s_all_lt['结算金额'].sum()
    # 件数：只计正单的数量字段sum
    day_lt_qty = int(s_today_lt[s_today_lt['结算金额'] > 0]['数量'].sum()) if len(s_today_lt[s_today_lt['结算金额'] > 0]) > 0 else 0
    month_lt_qty = int(s_all_lt[s_all_lt['结算金额'] > 0]['数量'].sum()) if len(s_all_lt[s_all_lt['结算金额'] > 0]) > 0 else 0
    lt_month_target = lt_targets[store]['month']
    lt_daily_target = lt_targets[store]['daily']
    lt_rate = month_lt_amt / lt_month_target * 100
    lt_day_rate = day_lt_amt / lt_daily_target * 100
    
    store_data[store] = {
        'day_amt': round(day_amt, 2),
        'wk28_amt': round(wk28_amt, 2),
        'month_amt': round(month_amt, 2),
        'day_rate': round(day_rate, 2),
        'month_rate': round(month_rate, 2),
        'day_yoy_pct': round(day_yoy, 2) if day_yoy is not None else None,
        'month_yoy_pct': round(month_yoy, 2) if month_yoy is not None else None,
        'day_jd': round(day_jd, 2),
        'day_kdj': round(day_kdj, 2),
        'day_cnt': day_cnt,
        'day_lt_amt': round(day_lt_amt, 2),
        'day_lt_qty': day_lt_qty,
        'month_lt_amt': round(month_lt_amt, 2),
        'month_lt_qty': month_lt_qty,
        'lt_rate': round(lt_rate, 2),
        'lt_day_rate': round(lt_day_rate, 2),
        'lt_daily_target': lt_daily_target,
        'lt_month_target': lt_month_target,
    }

# --- WOS数据 ---
wos_data = {}
for store in STORE_ORDER:
    s_today = today_all[today_all['门店名'] == store]
    s_wk28 = all_df[(all_df['门店名'] == store) & all_df['is_current_wk']]
    s_all = all_df[all_df['门店名'] == store]
    
    wos_today = s_today[s_today['支付方式名称'].str.contains('WOS', na=False)]
    wos_wk28 = s_wk28[s_wk28['支付方式名称'].str.contains('WOS', na=False)]
    wos_all = s_all[s_all['支付方式名称'].str.contains('WOS', na=False)]
    
    day_amt = wos_today['结算金额'].sum()
    wk28_amt = wos_wk28['结算金额'].sum()
    month_amt = wos_all['结算金额'].sum()
    
    store_day_total = s_today['结算金额'].sum()
    store_wk28_total = s_wk28['结算金额'].sum()
    store_month_total = s_all['结算金额'].sum()
    
    wos_data[store] = {
        'day_amt': round(day_amt, 2),
        'wk28_amt': round(wk28_amt, 2),
        'month_amt': round(month_amt, 2),
        'day_pct': round(day_amt / store_day_total * 100, 1) if store_day_total != 0 else 0,
        'wk28_pct': round(wk28_amt / store_wk28_total * 100, 1) if store_wk28_total != 0 else 0,
        'month_pct': round(month_amt / store_month_total * 100, 1) if store_month_total != 0 else 0,
    }

# --- 即时零售数据 ---
jl_data = {}
for store in STORE_ORDER:
    s_today = today_all[today_all['门店名'] == store]
    s_wk28 = all_df[(all_df['门店名'] == store) & all_df['is_current_wk']]
    s_all = all_df[all_df['门店名'] == store]
    
    def is_jl(df):
        cond = df['支付方式名称'].str.contains('美团', na=False)
        cond = cond | df['特殊销售类型'].str.contains('饿了么', na=False)
        cond = cond | df['支付方式名称'].str.contains('淘宝', na=False)
        cond = cond | df['支付方式名称'].str.contains('京东', na=False)
        return df[cond]
    
    jl_today = is_jl(s_today)
    jl_wk28 = is_jl(s_wk28)
    jl_all = is_jl(s_all)
    
    day_amt = jl_today['结算金额'].sum()
    wk28_amt = jl_wk28['结算金额'].sum()
    month_amt = jl_all['结算金额'].sum()
    
    store_day_total = s_today['结算金额'].sum()
    store_wk28_total = s_wk28['结算金额'].sum()
    store_month_total = s_all['结算金额'].sum()
    
    jl_data[store] = {
        'day_amt': round(day_amt, 2),
        'wk28_amt': round(wk28_amt, 2),
        'month_amt': round(month_amt, 2),
        'day_pct': round(day_amt / store_day_total * 100, 1) if store_day_total != 0 else 0,
        'wk28_pct': round(wk28_amt / store_wk28_total * 100, 1) if store_wk28_total != 0 else 0,
        'month_pct': round(month_amt / store_month_total * 100, 1) if store_month_total != 0 else 0,
    }

# --- 导购数据 ---
guide_sales = {}
for gname, info in guide_info.items():
    store = info['store']
    # 匹配导购姓名（订单中的导购字段）
    g_today = today_all[(today_all['门店名'] == store) & (today_all['导购姓名'].astype(str).str.strip() == gname)]
    g_wk28 = all_df[(all_df['门店名'] == store) & all_df['is_current_wk'] & (all_df['导购姓名'].astype(str).str.strip() == gname)]
    g_all = all_df[(all_df['门店名'] == store) & (all_df['导购姓名'].astype(str).str.strip() == gname)]
    
    # 也要匹配长期兼职前缀版本
    alt_name = f'长期兼职-{gname}'
    g_today2 = today_all[(today_all['门店名'] == store) & (today_all['导购姓名'].astype(str).str.strip() == alt_name)]
    g_wk282 = all_df[(all_df['门店名'] == store) & all_df['is_current_wk'] & (all_df['导购姓名'].astype(str).str.strip() == alt_name)]
    g_all2 = all_df[(all_df['门店名'] == store) & (all_df['导购姓名'].astype(str).str.strip() == alt_name)]
    
    day_amt = g_today['结算金额'].sum() + g_today2['结算金额'].sum()
    wk28_amt = g_wk28['结算金额'].sum() + g_wk282['结算金额'].sum()
    month_amt = g_all['结算金额'].sum() + g_all2['结算金额'].sum()
    
    guide_sales[gname] = {
        'store': store,
        'title': info['title'],
        'target': info['target'],
        'day': round(day_amt, 2),
        'wk28': round(wk28_amt, 2),
        'month': round(month_amt, 2),
        'wk_wos': round(g_wk28[g_wk28['支付方式名称'].str.contains('WOS', na=False)]['结算金额'].sum() + g_wk282[g_wk282['支付方式名称'].str.contains('WOS', na=False)]['结算金额'].sum(), 2),
    }

# 也处理李婷1和黄小莉1的支援匹配
for special in ['李婷1', '黄小莉1']:
    if special == '李婷1':
        orig_name = '扬万支援销售'
        store = '扬州万象汇'
    else:
        orig_name = '泰州万象城-支援2'
        store = '泰州万象城'
    
    g_today_sp = today_all[(today_all['门店名'] == store) & (today_all['导购姓名'].astype(str).str.strip() == orig_name)]
    g_wk28_sp = all_df[(all_df['门店名'] == store) & all_df['is_current_wk'] & (all_df['导购姓名'].astype(str).str.strip() == orig_name)]
    g_all_sp = all_df[(all_df['门店名'] == store) & (all_df['导购姓名'].astype(str).str.strip() == orig_name)]
    
    # 也匹配"泰州万象城支援2"（无中划线版本）
    if special == '黄小莉1':
        alt_orig = '泰州万象城支援2'
        g_today_sp2 = today_all[(today_all['门店名'] == store) & (today_all['导购姓名'].astype(str).str.strip() == alt_orig)]
        g_wk28_sp2 = all_df[(all_df['门店名'] == store) & all_df['is_current_wk'] & (all_df['导购姓名'].astype(str).str.strip() == alt_orig)]
        g_all_sp2 = all_df[(all_df['门店名'] == store) & (all_df['导购姓名'].astype(str).str.strip() == alt_orig)]
        g_today_sp = pd.concat([g_today_sp, g_today_sp2])
        g_wk28_sp = pd.concat([g_wk28_sp, g_wk28_sp2])
        g_all_sp = pd.concat([g_all_sp, g_all_sp2])
    
    if special in guide_sales:
        guide_sales[special]['day'] += g_today_sp['结算金额'].sum()
        guide_sales[special]['wk28'] += g_wk28_sp['结算金额'].sum()
        guide_sales[special]['month'] += g_all_sp['结算金额'].sum()
        guide_sales[special]['wk_wos'] += g_wk28_sp[g_wk28_sp['支付方式名称'].str.contains('WOS', na=False)]['结算金额'].sum()

# ============================================================
# 5b. 重点SKU开单数据
# ============================================================
print("5b. 计算重点SKU开单数据...")

# 统一乐高编号
all_df['乐高编号_int'] = all_df['乐高编号'].apply(lambda x: str(int(float(x))) if pd.notna(x) and x != '' else '')
today_df_only = all_df[all_df['is_today']]

def calc_sku_stats(sku_dict, label):
    """计算某组SKU在各门店的日/月开单数量（正单数量字段sum）"""
    results = {}
    for sku_code, sku_name in sku_dict.items():
        sku_all = all_df[(all_df['乐高编号_int'] == sku_code) & (all_df['结算金额'] > 0)]
        sku_today = today_df_only[(today_df_only['乐高编号_int'] == sku_code) & (today_df_only['结算金额'] > 0)]
        store_data = {}
        for store in STORE_ORDER:
            month_qty = int(sku_all[sku_all['门店名'] == store]['数量'].sum()) if len(sku_all[sku_all['门店名'] == store]) > 0 else 0
            day_qty = int(sku_today[sku_today['门店名'] == store]['数量'].sum()) if len(sku_today[sku_today['门店名'] == store]) > 0 else 0
            store_data[store] = {'day': day_qty, 'month': month_qty}
        # 区域合计
        store_data['区域合计'] = {
            'day': int(sku_today['数量'].sum()) if len(sku_today) > 0 else 0,
            'month': int(sku_all['数量'].sum()) if len(sku_all) > 0 else 0,
        }
        results[sku_code] = {'name': sku_name, 'stores': store_data}
    return results

key_sku_data = calc_sku_stats(KEY_SKUS, '重点款')
keychain_sku_data = calc_sku_stats(KEYCHAIN_SKUS, '钥匙扣')

# ============================================================
# 6. 保存JSON数据
# ============================================================
print("6. 保存JSON数据...")
json_data = {
    'region': {
        'day_amt': round(region_day_amt, 2),
        'month_amt': round(region_month_amt, 2),
        'wk28_amt': round(all_df[all_df['is_current_wk']]['结算金额'].sum(), 2),
        'day_target': region_daily_target,
        'month_target': region_month_target,
        'day_rate': round(region_day_rate, 2),
        'month_rate': round(region_month_rate, 2),
        'day_yoy_pct': round(region_day_yoy, 2),
        'month_yoy_pct': round(region_month_yoy, 2),
        'day_jd': round(len(today_all[today_all['结算金额'] > 0]) / today_all[today_all['结算金额'] > 0]['单号'].nunique(), 2) if today_all[today_all['结算金额'] > 0]['单号'].nunique() > 0 else 0,
        'day_kdj': round(today_all[today_all['结算金额'] > 0]['结算金额'].sum() / today_all[today_all['结算金额'] > 0]['单号'].nunique(), 2) if today_all[today_all['结算金额'] > 0]['单号'].nunique() > 0 else 0,
    },
    'stores': store_data,
    'wos': wos_data,
    'jl': jl_data,
    'guide': guide_sales,
    'store_monthly_targets': store_targets,
    'store_daily_targets': {s: store_targets[s]['daily'] for s in store_targets},
    'store_lt_monthly_targets': lt_targets,
    'store_yoy_day': {s: yoy_data[s]['day'] for s in yoy_data},
    'store_yoy_month_cum': {s: yoy_data[s]['month_cum'] for s in yoy_data},
}
with open(OUTPUT_JSON, 'w') as f:
    json.dump(json_data, f, ensure_ascii=False, indent=2)

# ============================================================
# 7. 生成HTML看板
# ============================================================
print("7. 生成HTML看板...")

def fmt_amt(v):
    """格式化金额"""
    if v is None:
        return 'N/A'
    if v < 0:
        return f'¥{v:,.0f}'
    return f'¥{v:,.0f}'

def amt_red(v):
    """金额显示，<=0标红"""
    if v is None:
        return 'N/A'
    if v <= 0:
        return f'<span style="color:var(--red);font-weight:700">{fmt_amt(v)}</span>'
    return fmt_amt(v)

def qty_red(v):
    """数量显示，<=0标红"""
    if v is None:
        return 'N/A'
    if v <= 0:
        return f'<span style="color:var(--red);font-weight:700">{v}</span>'
    return str(v)

def fmt_wan(v):
    """格式化万元单位金额"""
    if v is None:
        return 'N/A'
    wan = v / 10000
    if abs(wan) >= 1:
        return f'¥{wan:.1f}万'
    else:
        return f'¥{v:,.0f}'

def fmt_pct(v, decimals=1):
    """格式化百分比"""
    if v is None:
        return 'N/A'
    return f'{v:.{decimals}f}%'

def fmt_yoy(v):
    """格式化同比"""
    if v is None:
        return '<span class="yoy-na">N/A</span>'
    if v < 0:
        return f'<span class="yoy-down">{v:.1f}%</span>'
    return f'<span class="yoy-up">+{v:.1f}%</span>'

def rate_color(rate):
    """完成率颜色"""
    if rate >= 50:
        return 'var(--green)', 'fill-rate-green'
    return 'var(--red)', 'fill-rate-red'

def rate_cell(rate):
    """完成率单元格（含迷你数据条）"""
    color, fill_cls = rate_color(rate)
    bar_width = min(rate, 100)
    return f'<td class="rate-bar-cell"><span style="color:{color}">{fmt_pct(rate)}</span><div class="rate-bar-mini"><div class="fill {fill_cls}" style="width:{bar_width:.1f}%"></div></div></td>'

# 导购按门店分组+按日销售降序
guide_by_store = {}
for store in STORE_ORDER:
    store_guides = {gname: info for gname, info in guide_sales.items() if info['store'] == store}
    # 按日销售降序
    sorted_guides = sorted(store_guides.items(), key=lambda x: x[1]['day'], reverse=True)
    guide_by_store[store] = sorted_guides

# --- 区域KPI卡片 ---
day_color, day_fill = rate_color(region_day_rate)
month_color, month_fill = rate_color(region_month_rate)

# 日同比标签
if region_day_yoy < 0:
    day_yoy_tag = f'<div class="tag tag-down">日同比 {fmt_pct(region_day_yoy)}</div>'
else:
    day_yoy_tag = f'<div class="tag tag-up">日同比 +{fmt_pct(region_day_yoy)}</div>'

if region_month_yoy < 0:
    month_yoy_tag = f'<div class="tag tag-down">月同比 {fmt_pct(region_month_yoy)}</div>'
else:
    month_yoy_tag = f'<div class="tag tag-up">月同比 +{fmt_pct(region_month_yoy)}</div>'

kpi_html = f'''
<!-- 核心KPI -->
<div class="kpi-row" style="grid-template-columns:repeat(4,1fr)">
  <div class="kpi-card" style="background:#fde8e8;border-color:#f5c6c6">
    <div class="label" style="color:#b91c1c">日销售</div>
    <div class="value" style="color:{'var(--red)' if region_day_amt <= 0 else '#b91c1c'}">{fmt_amt(region_day_amt)}</div>
    <div class="sub" style="color:#b91c1c">日指标 {fmt_wan(region_daily_target)} | 完成率 <span style="font-weight:700;color:{day_color}">{fmt_pct(region_day_rate)}</span></div>
    <div class="rate-bar-mini" style="width:100%;margin-top:4px"><div class="fill {day_fill}" style="width:{min(region_day_rate,100):.1f}%"></div></div>
    {day_yoy_tag}
  </div>
  <div class="kpi-card" style="background:#eff6ff;border-color:#bfdbfe">
    <div class="label" style="color:#1e40af">月累计销售</div>
    <div class="value" style="color:{'var(--red)' if region_month_amt <= 0 else '#1e40af'}">{fmt_amt(region_month_amt)}</div>
    <div class="sub" style="color:#1e40af">月指标 {fmt_wan(region_month_target)} | 完成率 <span style="font-weight:700;color:{month_color}">{fmt_pct(region_month_rate)}</span></div>
    <div class="rate-bar-mini" style="width:100%;margin-top:4px"><div class="fill {month_fill}" style="width:{min(region_month_rate,100):.1f}%"></div></div>
    {month_yoy_tag}
  </div>
  <div class="kpi-card" style="background:#fff7ed;border-color:#fed7aa">
    <div class="label" style="color:#c2410c">📦 长尾款 日销售</div>
    <div class="value" style="color:{'var(--red)' if region_lt_day_amt <= 0 else '#ea580c'}">{fmt_amt(region_lt_day_amt)}</div>
    <div class="sub" style="color:#c2410c">日指标 {fmt_wan(region_lt_daily_target)} | 完成率 <span style="font-weight:700;color:{'var(--green)' if region_lt_day_rate >= 50 else 'var(--red)'}">{fmt_pct(region_lt_day_rate)}</span> | {region_lt_day_qty}件</div>
    <div class="rate-bar-mini" style="width:100%;margin-top:4px"><div class="fill {'fill-rate-green' if region_lt_day_rate >= 50 else 'fill-rate-red'}" style="width:{min(region_lt_day_rate,100):.1f}%"></div></div>
  </div>
  <div class="kpi-card" style="background:#fff7ed;border-color:#fed7aa">
    <div class="label" style="color:#c2410c">📦 长尾款 月目标</div>
    <div class="value" style="color:{'var(--red)' if region_lt_month_amt <= 0 else '#ea580c'}">{fmt_amt(region_lt_month_amt)}</div>
    <div class="sub" style="color:#c2410c">月指标 {fmt_wan(region_lt_month_target)} | 完成率 <span style="font-weight:700;color:{'var(--green)' if region_lt_month_rate >= 50 else 'var(--red)'}">{fmt_pct(region_lt_month_rate)}</span> | {region_lt_month_qty}件</div>
    <div class="rate-bar-mini" style="width:100%;margin-top:4px"><div class="fill {'fill-rate-green' if region_lt_month_rate >= 50 else 'fill-rate-red'}" style="width:{min(region_lt_month_rate,100):.1f}%"></div></div>
  </div>
</div>
'''

# --- 门店KPI表 ---
# 门店按日完成率从高到低排序
sorted_stores = sorted(STORE_ORDER, key=lambda s: store_data[s]['day_rate'], reverse=True)
store_rows = ''
for store in sorted_stores:
    sd = store_data[store]
    day_amt_str = amt_red(sd["day_amt"])
    month_amt_str = amt_red(sd["month_amt"])
    day_target_str = fmt_wan(store_targets[store]["daily"])
    month_target_str = fmt_wan(store_targets[store]["month"])
    
    store_rows += f'''
      <tr>
        <td class="store-name">{store}</td>
        <td class="num">{amt_red(sd['day_amt'])}</td>
        <td>{day_target_str}</td>
        {rate_cell(sd['day_rate'])}
        <td>{fmt_yoy(sd['day_yoy_pct'])}</td>
        <td class="num">{amt_red(sd['month_amt'])}</td>
        <td>{month_target_str}</td>
        {rate_cell(sd['month_rate'])}
        <td>{fmt_yoy(sd['month_yoy_pct'])}</td>
        <td>{sd['day_jd']:.2f}</td>
        <td>¥{sd['day_kdj']:,.0f}</td>
      </tr>'''

# 区域合计行
region_total_row = f'''
      <tr style="background:#7c3aed35;font-weight:700">
        <td class="store-name">苏中区域</td>
        <td class="num">{amt_red(region_day_amt)}</td>
        <td>{fmt_wan(region_daily_target)}</td>
        {rate_cell(region_day_rate)}
        <td>{fmt_yoy(region_day_yoy)}</td>
        <td class="num">{amt_red(region_month_amt)}</td>
        <td>{fmt_wan(region_month_target)}</td>
        {rate_cell(region_month_rate)}
        <td>{fmt_yoy(region_month_yoy)}</td>
        <td>{json_data["region"]["day_jd"]:.2f}</td>
        <td>¥{json_data["region"]["day_kdj"]:,.0f}</td>
      </tr>'''

store_kpi_html = f'''
<!-- 门店KPI -->
<div class="section">
  <div class="section-title section-title-store"><span class="section-icon">🏪</span>门店 KPI 详情</div>
  <div class="table-wrap">
  <table>
    <thead style="background:#7c3aed25;">
      <tr>
        <th style="text-align:left;color:#7c3aed;">门店</th>
        <th style="color:#7c3aed;">日销售</th>
        <th style="color:#7c3aed;">日指标</th>
        <th style="color:#7c3aed;">日完成率</th>
        <th style="color:#7c3aed;">日同比</th>
        <th style="color:#7c3aed;">月累计</th>
        <th style="color:#7c3aed;">月指标</th>
        <th style="color:#7c3aed;">月完成率</th>
        <th style="color:#7c3aed;">月同比</th>
        <th style="color:#7c3aed;">连带率(日)</th>
        <th style="color:#7c3aed;">客单价(日)</th>
      </tr>
    </thead>
    <tbody>
{store_rows}
{region_total_row}
    </tbody>
  </table>
  </div>
</div>
'''

# --- 长尾款表 ---
# 门店按长尾款日销售从高到低排序
lt_sorted_stores = sorted(STORE_ORDER, key=lambda s: store_data[s]['day_lt_amt'], reverse=True)
lt_rows = ''
lt_month_total = 0
lt_day_total = 0
lt_day_qty_total = 0
lt_month_qty_total = 0
for store in lt_sorted_stores:
    sd = store_data[store]
    lt_month_total += sd['month_lt_amt']
    lt_day_total += sd['day_lt_amt']
    lt_day_qty_total += sd['day_lt_qty']
    lt_month_qty_total += sd['month_lt_qty']
    
    # 日销售颜色
    day_lt_style = f'color:var(--red);font-weight:700' if sd['day_lt_amt'] <= 0 else ''
    
    # 占比 = 长尾款金额 / 门店总销售金额
    day_pct = sd['day_lt_amt'] / sd['day_amt'] * 100 if sd['day_amt'] != 0 else 0
    month_pct = sd['month_lt_amt'] / sd['month_amt'] * 100 if sd['month_amt'] != 0 else 0
    
    # 占比颜色：>=10%绿色，<10%红色
    day_pct_color = '#16a34a' if day_pct >= 10 else '#dc2626'
    month_pct_color = '#16a34a' if month_pct >= 10 else '#dc2626'
    
    lt_rows += f'''
      <tr>
        <td class="store-name">{store}</td>
        <td class="num" {f'style="{day_lt_style}"' if day_lt_style else ''}>{amt_red(sd['day_lt_amt'])}/{sd['day_lt_qty']}件</td>
        <td style="color:{day_pct_color};font-weight:700;">{fmt_pct(day_pct)}</td>
        <td class="num">{amt_red(sd['month_lt_amt'])}/{sd['month_lt_qty']}件</td>
        <td style="color:{month_pct_color};font-weight:700;">{fmt_pct(month_pct)}</td>
      </tr>'''

# 区域合计占比
lt_region_day_pct = lt_day_total / region_day_amt * 100 if region_day_amt != 0 else 0
lt_region_month_pct = lt_month_total / region_month_amt * 100 if region_month_amt != 0 else 0
lt_region_day_color = '#16a34a' if lt_region_day_pct >= 10 else '#dc2626'
lt_region_month_color = '#16a34a' if lt_region_month_pct >= 10 else '#dc2626'

lt_region_row = f'''
      <tr style="background:#ea580c35;font-weight:700">
        <td class="store-name">苏中区域</td>
        <td class="num">{amt_red(lt_day_total)}/{lt_day_qty_total}件</td>
        <td style="color:{lt_region_day_color};font-weight:700;">{fmt_pct(lt_region_day_pct)}</td>
        <td class="num">{amt_red(lt_month_total)}/{lt_month_qty_total}件</td>
        <td style="color:{lt_region_month_color};font-weight:700;">{fmt_pct(lt_region_month_pct)}</td>
      </tr>'''

longtail_html = f'''
<!-- 长尾款 -->
<div class="section">
  <div class="section-title section-title-longtail"><span class="section-icon">📦</span>长尾款 销售详情</div>
  <div class="table-wrap">
  <table>
    <thead style="background:#ea580c25;">
      <tr>
        <th style="text-align:left;color:#ea580c;">门店</th>
        <th style="color:#ea580c;">日销售</th>
        <th style="color:#ea580c;">日销售占比</th>
        <th style="color:#ea580c;">月累计</th>
        <th style="color:#ea580c;">月度销售占比</th>
      </tr>
    </thead>
    <tbody>
{lt_rows}
{lt_region_row}
    </tbody>
  </table>
  </div>
</div>
'''

# --- 导购表 ---
guide_html_parts = ''
for store in STORE_ORDER:
    guides = guide_by_store.get(store, [])
    if not guides:
        continue
    
    guide_rows = ''
    day_sum = 0
    wk28_sum = 0
    wk_wos_sum = 0
    month_sum = 0
    target_sum = 0
    
    for gname, info in guides:
        day_sum += info['day']
        wk28_sum += info['wk28']
        wk_wos_sum += info.get('wk_wos', 0)
        month_sum += info['month']
        target_sum += info['target']
        
        guide_rows += f'''
        <tr>
          <td class="store-name">{gname}</td>
          <td style="font-size:11px;color:var(--text-sub)">{info['title']}</td>
          <td class="num">{amt_red(info['day'])}</td>
          <td class="num">{amt_red(info['wk28'])}</td>
          <td class="num">{amt_red(info.get('wk_wos', 0))}</td>
          <td class="num">{amt_red(info['month'])}</td>
          <td>{fmt_wan(info['target'])}</td>
          {rate_cell(info['month'] / info['target'] * 100 if info['target'] > 0 else 0)}
        </tr>'''
    
    # 合计行
    total_rate = month_sum / target_sum * 100 if target_sum > 0 else 0
    guide_rows += f'''
        <tr style="background:#05966915;font-weight:700">
          <td class="store-name">合计</td>
          <td>-</td>
          <td class="num">{amt_red(day_sum)}</td>
          <td class="num">{amt_red(wk28_sum)}</td>
          <td class="num">{amt_red(wk_wos_sum)}</td>
          <td class="num">{amt_red(month_sum)}</td>
          <td>{fmt_wan(target_sum)}</td>
          {rate_cell(total_rate)}
        </tr>'''
    
    guide_html_parts += f'''
  <div class="guide-group">
    <div class="guide-group-title">📍 {store}</div>
    <div class="guide-table-wrap">
    <table>
      <thead style="background:#05966925;">
        <tr>
          <th style="text-align:left">导购</th>
          <th>职务</th>
          <th>日销售</th>
          <th>{WK_NUM}周</th>
          <th>{WK_NUM} WOS</th>
          <th>月累计</th>
          <th>月指标</th>
          <th>月完成率</th>
        </tr>
      </thead>
      <tbody>
{guide_rows}
      </tbody>
    </table>
    </div>
  </div>'''

guide_section_html = f'''
<!-- 导购 -->
<div class="section">
  <div class="section-title section-title-guide"><span class="section-icon">👩</span>导购 销售详情</div>
{guide_html_parts}
</div>
'''

# --- WOS表 ---
wos_rows = ''
wos_day_total = 0
wos_wk28_total = 0
wos_month_total = 0
region_day_total_all = today_all['结算金额'].sum()
region_wk28_total_all = all_df[all_df['is_current_wk']]['结算金额'].sum()
region_month_total_all = all_df['结算金额'].sum()

for store in STORE_ORDER:
    wd = wos_data[store]
    wos_day_total += wd['day_amt']
    wos_wk28_total += wd['wk28_amt']
    wos_month_total += wd['month_amt']
    
    wos_rows += f'''
      <tr>
        <td class="store-name">{store}</td>
        <td class="num">{amt_red(wd['day_amt'])}</td>
        <td>{fmt_pct(wd['day_pct'])}</td>
        <td class="num">{amt_red(wd['wk28_amt'])}</td>
        <td>{fmt_pct(wd['wk28_pct'])}</td>
        <td class="num">{amt_red(wd['month_amt'])}</td>
        <td>{fmt_pct(wd['month_pct'])}</td>
      </tr>'''

wos_region_row = f'''
      <tr style="background:#0284c735;font-weight:700">
        <td class="store-name">苏中区域</td>
        <td class="num">{amt_red(wos_day_total)}</td>
        <td>{fmt_pct(wos_day_total / region_day_total_all * 100 if region_day_total_all != 0 else 0)}</td>
        <td class="num">{amt_red(wos_wk28_total)}</td>
        <td>{fmt_pct(wos_wk28_total / region_wk28_total_all * 100 if region_wk28_total_all != 0 else 0)}</td>
        <td class="num">{amt_red(wos_month_total)}</td>
        <td>{fmt_pct(wos_month_total / region_month_total_all * 100 if region_month_total_all != 0 else 0)}</td>
      </tr>'''

wos_html = f'''
<!-- WOS销售 -->
<div class="section">
  <div class="section-title section-title-channel"><span class="section-icon">🔗</span>WOS 企微小程序</div>
  <div class="table-wrap">
  <table>
    <thead style="background:#0284c725;">
      <tr>
        <th style="text-align:left;color:#0284c7;">门店</th>
        <th style="color:#0284c7;">日销售</th>
        <th style="color:#0284c7;">日占比</th>
        <th style="color:#0284c7;">{WK_NUM}周</th>
        <th style="color:#0284c7;">{WK_NUM}占比</th>
        <th style="color:#0284c7;">月累计</th>
        <th style="color:#0284c7;">月占比</th>
      </tr>
    </thead>
    <tbody>
{wos_rows}
{wos_region_row}
    </tbody>
  </table>
  </div>
</div>
'''

# --- 即时零售表 ---
jl_rows = ''
jl_day_total = 0
jl_wk28_total = 0
jl_month_total = 0

for store in STORE_ORDER:
    jd = jl_data[store]
    jl_day_total += jd['day_amt']
    jl_wk28_total += jd['wk28_amt']
    jl_month_total += jd['month_amt']
    
    jl_rows += f'''
      <tr>
        <td class="store-name">{store}</td>
        <td class="num">{amt_red(jd['day_amt'])}</td>
        <td>{fmt_pct(jd['day_pct'])}</td>
        <td class="num">{amt_red(jd['wk28_amt'])}</td>
        <td>{fmt_pct(jd['wk28_pct'])}</td>
        <td class="num">{amt_red(jd['month_amt'])}</td>
        <td>{fmt_pct(jd['month_pct'])}</td>
      </tr>'''

jl_region_row = f'''
      <tr style="background:#0284c735;font-weight:700">
        <td class="store-name">苏中区域</td>
        <td class="num">{amt_red(jl_day_total)}</td>
        <td>{fmt_pct(jl_day_total / region_day_total_all * 100 if region_day_total_all != 0 else 0)}</td>
        <td class="num">{amt_red(jl_wk28_total)}</td>
        <td>{fmt_pct(jl_wk28_total / region_wk28_total_all * 100 if region_wk28_total_all != 0 else 0)}</td>
        <td class="num">{amt_red(jl_month_total)}</td>
        <td>{fmt_pct(jl_month_total / region_month_total_all * 100 if region_month_total_all != 0 else 0)}</td>
      </tr>'''

jl_html = f'''
<!-- 即时零售 -->
<div class="section">
  <div class="section-title section-title-channel"><span class="section-icon">⚡</span>即时零售</div>
  <div class="table-wrap">
  <table>
    <thead style="background:#0284c725;">
      <tr>
        <th style="text-align:left;color:#0284c7;">门店</th>
        <th style="color:#0284c7;">日销售</th>
        <th style="color:#0284c7;">日占比</th>
        <th style="color:#0284c7;">{WK_NUM}周</th>
        <th style="color:#0284c7;">{WK_NUM}占比</th>
        <th style="color:#0284c7;">月累计</th>
        <th style="color:#0284c7;">月占比</th>
      </tr>
    </thead>
    <tbody>
{jl_rows}
{jl_region_row}
    </tbody>
  </table>
  </div>
</div>
'''

# --- 重点SKU开单跟踪表 ---
def build_sku_table(sku_data, section_title, section_icon, section_color, border_color):
    """生成重点SKU开单跟踪表HTML（只显示日开单数量）"""
    # 构建表头
    sku_codes = list(sku_data.keys())
    header_cols = ''
    for code in sku_codes:
        name = sku_data[code]['name']
        header_cols += f'<th>{name}</th>'
    
    header_html = f'''<tr style="background:{section_color}25;">
      <th style="color:{section_color};">门店</th>
      {header_cols}
    </tr>'''
    
    # 构建门店行
    rows_html = ''
    for store in STORE_ORDER:
        row = f'<tr><td style="font-weight:600;">{store}</td>'
        for code in sku_codes:
            sd = sku_data[code]['stores'][store]
            day_val = sd['day']
            day_cls = 'color:var(--red);font-weight:700;' if day_val <= 0 else 'color:#16a34a;font-weight:700;'
            row += f'<td style="{day_cls}">{day_val}</td>'
        row += '</tr>'
        rows_html += row
    
    # 区域合计行
    total_row = f'<tr style="background:{section_color}35;font-weight:700;"><td>区域合计</td>'
    for code in sku_codes:
        sd = sku_data[code]['stores']['区域合计']
        day_val = sd['day']
        total_cls = 'color:var(--red);font-weight:700;' if day_val <= 0 else 'color:#16a34a;font-weight:700;'
        total_row += f'<td style="{total_cls}">{day_val}</td>'
    total_row += '</tr>'
    
    table_html = f'''
<div class="section">
  <div class="section-title" style="background:{section_color};border-left:4px solid {border_color};">
    <span class="section-icon">{section_icon}</span>{section_title}
  </div>
  <div style="overflow-x:auto;">
  <table style="width:100%;border-collapse:collapse;font-size:13px;">
    <thead>
{header_html}
    </thead>
    <tbody>
{rows_html}
{total_row}
    </tbody>
  </table>
  </div>
</div>'''
    return table_html

key_sku_html = build_sku_table(key_sku_data, '重点SKU 开单跟踪', '🔑', '#dc2626', '#ef4444')
keychain_sku_html = ''  # 已合并到key_sku_html

# --- 门店月度完成率柱状图 ---
STORE_CHART_COLORS = {
    '扬州万象汇': '#7F77DD', '扬州京华城': '#378ADD', '扬州江都金鹰': '#1D9E75',
    '泰州万象城': '#D85A30', '宿迁宝龙': '#EF9F27', '淮安新亚': '#639922', '淮安万象城': '#D4537E'
}
store_chart_items = []
for sname in STORE_ORDER:
    sd = store_data[sname]
    store_chart_items.append({
        'name': sname,
        'month': round(sd['month_amt']),
        'target': round(store_targets[sname]['month']),
        'rate': round(sd['month_rate'], 1),
        'color': STORE_CHART_COLORS.get(sname, '#888888')
    })
store_chart_items.sort(key=lambda x: x['rate'], reverse=True)
store_chart_json = json.dumps(store_chart_items, ensure_ascii=False)

store_chart_html = f'''
<!-- 门店月度完成率柱状图 -->
<div class="section">
  <div class="section-title section-title-store"><span class="section-icon">📊</span>门店 月度完成率排行</div>
  <div style="position:relative;width:100%;height:360px;background:var(--card);border-radius:8px;padding:16px;">
    <canvas id="storeRateChart" role="img" aria-label="门店月度销售完成率柱状图">Fallback text.</canvas>
  </div>
</div>
<script>
(function(){{
  const items = {store_chart_json};
  const ctx = document.getElementById('storeRateChart');
  if(!ctx) return;
  new Chart(ctx, {{
    type:'bar',
    data:{{
      labels: items.map(g => g.name),
      datasets:[{{
        label:'月度完成率(%)',
        data: items.map(g => g.rate),
        backgroundColor: items.map(g => g.color),
        borderRadius: 4,
        barThickness: 40
      }}]
    }},
    options:{{
      responsive:true,
      maintainAspectRatio:false,
      plugins:{{
        legend:{{display:false}},
        tooltip:{{
          callbacks:{{
            label:function(c){{
              const g = items[c.dataIndex];
              return '完成率 '+g.rate+'%  |  月累计 ¥'+g.month.toLocaleString()+'  |  月指标 ¥'+g.target.toLocaleString();
            }}
          }}
        }}
      }},
      scales:{{
        y:{{title:{{display:true,text:'月度完成率 (%)',font:{{size:12}}}},ticks:{{font:{{size:11}}}},grid:{{color:'rgba(128,128,128,0.1)'}}}},
        x:{{ticks:{{font:{{size:12}}}},grid:{{display:false}}}}
      }}
    }},
    plugins:[{{
      id:'barLabels',
      afterDatasetsDraw(chart){{
        const ctx2=chart.ctx; const meta=chart.getDatasetMeta(0);
        ctx2.save(); ctx2.font='bold 12px sans-serif'; ctx2.textAlign='center';
        meta.data.forEach((bar,i)=>{{
          ctx2.fillStyle='#333';
          ctx2.fillText(items[i].rate+'%',bar.x,bar.y-5);
        }});
        ctx2.restore();
      }}
    }}]
  }});
}})();
</script>
'''

# --- 导购完成率柱状图 ---
guide_chart_items = []
for gname, info in guide_sales.items():
    rate = info['month'] / info['target'] * 100 if info['target'] > 0 else 0
    guide_chart_items.append({
        'name': gname, 'store': info['store'], 'title': info['title'],
        'month': round(info['month']), 'target': round(info['target']),
        'rate': round(rate, 1), 'color': STORE_CHART_COLORS.get(info['store'], '#888888')
    })
guide_chart_items.sort(key=lambda x: x['rate'], reverse=True)
guide_chart_json = json.dumps(guide_chart_items, ensure_ascii=False)

guide_chart_html = f'''
<!-- 导购完成率柱状图 -->
<div class="section">
  <div class="section-title section-title-guide"><span class="section-icon">📊</span>导购 月度完成率排行</div>
  <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:8px;font-size:12px;color:var(--text-sub);">
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#7F77DD;"></span>扬州万象汇</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#378ADD;"></span>扬州京华城</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#1D9E75;"></span>扬州江都金鹰</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#D85A30;"></span>泰州万象城</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#EF9F27;"></span>宿迁宝龙</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#639922;"></span>淮安新亚</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#D4537E;"></span>淮安万象城</span>
  </div>
  <div style="position:relative;width:100%;height:420px;background:var(--card);border-radius:8px;padding:16px;">
    <canvas id="guideRateChart" role="img" aria-label="全体导购月度销售完成率柱状图">Fallback text.</canvas>
  </div>
</div>
<script>
(function(){{
  const items = {guide_chart_json};
  const ctx = document.getElementById('guideRateChart');
  if(!ctx) return;
  new Chart(ctx, {{
    type:'bar',
    data:{{
      labels: items.map(g => g.name),
      datasets:[{{
        label:'月度完成率(%)',
        data: items.map(g => g.rate),
        backgroundColor: items.map(g => g.color),
        borderRadius: 3,
        barThickness: 20
      }}]
    }},
    options:{{
      responsive:true,
      maintainAspectRatio:false,
      plugins:{{
        legend:{{display:false}},
        tooltip:{{
          callbacks:{{
            label:function(c){{
              const g = items[c.dataIndex];
              return '完成率 '+g.rate+'%  |  月累计 ¥'+g.month.toLocaleString()+'  |  月指标 ¥'+g.target.toLocaleString()+'  |  '+g.store;
            }}
          }}
        }}
      }},
      scales:{{
        y:{{title:{{display:true,text:'月度完成率 (%)',font:{{size:12}}}},ticks:{{font:{{size:11}}}},grid:{{color:'rgba(128,128,128,0.1)'}}}},
        x:{{ticks:{{font:{{size:11}},maxRotation:90,minRotation:45}},grid:{{display:false}}}}
      }}
    }},
    plugins:[{{
      id:'barLabels',
      afterDatasetsDraw(chart){{
        const ctx2=chart.ctx; const meta=chart.getDatasetMeta(0);
        ctx2.save(); ctx2.font='bold 10px sans-serif'; ctx2.textAlign='center';
        meta.data.forEach((bar,i)=>{{
          ctx2.fillStyle='#333';
          ctx2.fillText(items[i].rate+'%',bar.x,bar.y-4);
        }});
        ctx2.restore();
      }}
    }}]
  }});
}})();
</script>
'''

# --- 导购WK周累计销售排名柱状图 ---
guide_wk_chart_items = []
for gname, info in guide_sales.items():
    guide_wk_chart_items.append({
        'name': gname, 'store': info['store'],
        'wk28': round(info['wk28']), 'month': round(info['month']),
        'color': STORE_CHART_COLORS.get(info['store'], '#888888')
    })
guide_wk_chart_items.sort(key=lambda x: x['wk28'], reverse=True)
guide_wk_chart_json = json.dumps(guide_wk_chart_items, ensure_ascii=False)

guide_wk_chart_html = f'''
<!-- 导购WK28周累计销售排名 -->
<div class="section">
  <div class="section-title section-title-guide"><span class="section-icon">📊</span>导购 {WK_NUM}周 累计销售排名</div>
  <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:8px;font-size:12px;color:var(--text-sub);">
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#7F77DD;"></span>扬州万象汇</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#378ADD;"></span>扬州京华城</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#1D9E75;"></span>扬州江都金鹰</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#D85A30;"></span>泰州万象城</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#EF9F27;"></span>宿迁宝龙</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#639922;"></span>淮安新亚</span>
    <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#D4537E;"></span>淮安万象城</span>
  </div>
  <div style="position:relative;width:100%;height:420px;background:var(--card);border-radius:8px;padding:16px;">
    <canvas id="guideWkChart" role="img" aria-label="导购WK28周累计销售排名纵向柱状图">Fallback text.</canvas>
  </div>
</div>
<script>
(function(){{
  const items = {guide_wk_chart_json};
  const ctx = document.getElementById('guideWkChart');
  if(!ctx) return;
  new Chart(ctx, {{
    type:'bar',
    data:{{
      labels: items.map(g => g.name),
      datasets:[{{
        label:'{WK_NUM}周累计销售',
        data: items.map(g => g.wk28),
        backgroundColor: items.map(g => g.color + '99'),
        borderColor: items.map(g => g.color),
        borderWidth: 1.5,
        barPercentage: 0.75
      }}]
    }},
    options:{{
      responsive:true,
      maintainAspectRatio:false,
      plugins:{{
        legend:{{display:false}},
        tooltip:{{
          callbacks:{{
            label:function(c){{
              const g = items[c.dataIndex];
              const val = c.raw;
              const abs = Math.abs(val);
              const formatted = abs >= 10000 ? '¥' + (abs/10000).toFixed(2) + '万' : '¥' + abs.toLocaleString();
              const sign = val < 0 ? '-' : '';
              return sign + formatted + '  |  ' + g.store;
            }}
          }}
        }}
      }},
      scales:{{
        y:{{title:{{display:true,text:'{WK_NUM}周累计销售 (¥)',font:{{size:12}}}},grid:{{color:'rgba(128,128,128,0.1)'}},ticks:{{font:{{size:11}},callback:function(v){{return v>=10000?(v/10000).toFixed(1)+'万':v.toLocaleString();}}}}}},
        x:{{grid:{{display:false}},ticks:{{font:{{size:11}},maxRotation:75,minRotation:45,autoSkip:false}}}}
      }}
    }},
    plugins:[{{
      id:'barLabels',
      afterDatasetsDraw(chart){{
        const ctx2=chart.ctx; const meta=chart.getDatasetMeta(0);
        ctx2.save(); ctx2.font='bold 11px sans-serif'; ctx2.textAlign='center';
        meta.data.forEach((bar,i)=>{{
          const val = items[i].wk28;
          const abs = Math.abs(val);
          const text = abs >= 10000 ? '¥' + (abs/10000).toFixed(1) + '万' : '¥' + abs.toLocaleString();
          const sign = val < 0 ? '-' : '';
          ctx2.fillStyle = val < 0 ? '#d62839' : '#333';
          ctx2.fillText(sign + text, bar.x, bar.y - 6);
        }});
        ctx2.restore();
      }}
    }}]
  }});
}})();
</script>
'''

# --- 组装完整HTML ---
full_html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>苏中区域 {REPORT_DATE} 销售看板</title>
<style>
  :root {{
    --bg: #f5f6fa; --card: #ffffff; --border: #e8eaed; --text: #1a1a2e; --text-sub: #6b7280;
    --red: #d62839; --green: #2d9d5a; --blue: #3b82f6; --yellow: #f59e0b; --purple: #8b5cf6;
    --accent: #1e40af; --red-bg: #fde8e8; --green-bg: #e6f7ed; --blue-bg: #eff6ff;
  }}
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ background:var(--bg); font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif; color:var(--text); padding:20px; font-size:15px; }}
  .header {{ background:linear-gradient(135deg,#1e40af,#3b82f6); color:#fff; padding:24px 32px; border-radius:12px; margin-bottom:24px; display:flex; justify-content:space-between; align-items:center; }}
  .header h1 {{ font-size:26px; font-weight:700; }}
  .header .region-label {{ font-size:18px; }}
  .kpi-row {{ display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }}
  .kpi-card {{ background:var(--card); border-radius:10px; padding:20px 24px; border:1px solid var(--border); position:relative; }}
  .kpi-card .label {{ font-size:14px; margin-bottom:8px; font-weight:500; }}
  .kpi-card .value {{ font-size:30px; font-weight:800; line-height:1.2; }}
  .kpi-card .sub {{ font-size:13px; color:var(--text-sub); margin-top:8px; }}
  .kpi-card .sub span {{ font-weight:600; }}
  .kpi-card .tag {{ position:absolute; top:14px; right:20px; font-size:12px; padding:3px 10px; border-radius:4px; font-weight:600; }}
  .tag-up {{ background:var(--green-bg); color:var(--green); }}
  .tag-down {{ background:var(--red-bg); color:var(--red); }}
  .rate-bar-mini {{ height:5px; background:#e8eaed; border-radius:2px; margin-top:5px; overflow:hidden; }}
  .rate-bar-mini .fill {{ height:100%; border-radius:2px; }}
  .fill-rate-red {{ background:var(--red); }}
  .fill-rate-green {{ background:var(--green); }}
  .section {{ margin-bottom:28px; }}
  .section-title {{ font-size:18px; font-weight:700; padding:16px 0 10px; border-bottom:2px solid; margin-bottom:16px; display:flex; align-items:center; gap:10px; }}
  .section-icon {{ font-size:20px; line-height:1; }}
  .section-title-store {{ color:#7c3aed; border-color:#8b5cf6; }}
  .section-title-longtail {{ color:#ea580c; border-color:#f97316; }}
  .section-title-guide {{ color:#059669; border-color:#10b981; }}
  .section-title-channel {{ color:#0284c7; border-color:#0ea5e9; }}
  .table-wrap {{ background:var(--card); border-radius:10px; border:1px solid var(--border); overflow-x:auto; -webkit-overflow-scrolling:touch; }}
  table {{ width:100%; border-collapse:collapse; font-size:14px; }}
  thead {{ background:#f0f2f5; }}
  th {{ padding:12px 14px; text-align:center; font-weight:600; font-size:13px; color:var(--text-sub); white-space:nowrap; }}
  td {{ padding:12px 14px; text-align:center; border-top:1px solid var(--border); white-space:nowrap; }}
  tbody tr:nth-child(even) {{ background:rgba(128,128,128,0.12); }}
  .store-name {{ text-align:left; font-weight:600; color:var(--text); min-width:90px; }}
  .num {{ font-weight:600; }}
  .yoy-up {{ color:var(--green); font-weight:600; }}
  .yoy-down {{ color:var(--red); font-weight:600; }}
  .yoy-na {{ color:var(--text-sub); }}
  .rate-bar-cell {{ min-width:85px; text-align:center; }}
  .guide-group {{ margin-bottom:16px; }}
  .guide-group-title {{ font-size:16px; font-weight:700; padding:10px 0 6px; color:var(--accent); display:flex; align-items:center; gap:8px; }}
  .guide-table-wrap {{ background:var(--card); border-radius:10px; border:1px solid var(--border); overflow-x:auto; -webkit-overflow-scrolling:touch; }}
  .page {{ display:none; }}
  .page.active {{ display:block; }}
  .nav-btn {{ display:inline-flex; align-items:center; gap:8px; padding:10px 20px; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; text-decoration:none; transition:background 0.2s; }}
  .nav-btn-guide {{ background:#059669; color:#fff; }}
  .nav-btn-guide:hover {{ background:#047857; }}
  .nav-btn-back {{ background:var(--card); color:#059669; border:1px solid #059669; }}
  .nav-btn-back:hover {{ background:#e6f7ed; }}
  @media(max-width:768px) {{
    body {{ padding:10px; font-size:14px; }}
    .header {{ padding:16px 18px; border-radius:8px; }}
    .header h1 {{ font-size:20px; }}
    .header .region-label {{ font-size:16px; }}
    .kpi-row {{ grid-template-columns:repeat(2,1fr); gap:10px; }}
    .kpi-card {{ padding:14px 16px; border-radius:8px; }}
    .kpi-card .value {{ font-size:24px; }}
    .kpi-card .tag {{ position:static; display:inline-block; margin-top:4px; }}
    .section-title {{ font-size:16px; }}
    table {{ font-size:12px; }}
    th, td {{ padding:8px 6px; }}
    .store-name {{ min-width:60px; }}
    .rate-bar-cell {{ min-width:60px; }}
    .guide-group-title {{ font-size:13px; }}
    .nav-btn {{ padding:8px 14px; font-size:13px; }}
  }}

</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
</head>
<body>

<div class="header">
  <div>
    <div class="region-label">🧱 苏中区域</div>
    <h1>日销售看板<span style="font-size:14px;font-weight:400;color:var(--text-sub);margin-left:8px;">{REPORT_DATE}</span></h1>
  </div>
  <div></div>
</div>

<div id="page1" class="page active">

{kpi_html}
{store_kpi_html}
{longtail_html}
{key_sku_html}

<!-- 导购详情导航按钮 -->
<div style="margin:20px 0;text-align:center;">
  <a class="nav-btn nav-btn-guide" onclick="showPage('page2')">👩 查看导购详情 →</a>
</div>

{wos_html}
{jl_html}
{store_chart_html}
{guide_chart_html}
{guide_wk_chart_html}

<div style="font-size:12px;color:var(--text-sub);padding:12px 0;border-top:1px solid var(--border);margin-top:8px;">
  💡 说明：数据使用结算金额，已排除赠品和样品。日同比和月同比排除淮安万象城（2025年12月新开店，无同期数据）。
  {WK_NUM}周累计为{WK_START.month}月{WK_START.day}日起至当日。WOS口径：支付方式名称含"WOS企微小程序"的所有订单。即时零售口径：支付方式含"美团"或特殊销售类型含"饿了么"或支付方式含"淘宝/京东"。长尾款口径：79款SKU明细匹配，结算金额含退货扣减。重点SKU开单数量仅计正单（退货不计入）。
</div>

</div><!-- page1 -->

<div id="page2" class="page">

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
  <a class="nav-btn nav-btn-back" onclick="showPage('page1')">← 返回看板</a>
  <div style="font-size:18px;font-weight:700;color:#059669;">👩 导购销售详情</div>
</div>

{guide_section_html}

<div style="font-size:12px;color:var(--text-sub);padding:12px 0;border-top:1px solid var(--border);margin-top:8px;text-align:center;">
  <a class="nav-btn nav-btn-back" onclick="showPage('page1')">← 返回看板首页</a>
</div>

</div><!-- page2 -->

<script>
function showPage(pageId) {{
  document.querySelectorAll('.page').forEach(function(p) {{
    p.classList.remove('active');
  }});
  document.getElementById(pageId).classList.add('active');
  window.scrollTo(0, 0);
}}
</script>

</body>
</html>'''

with open(OUTPUT_HTML, 'w', encoding='utf-8') as f:
    f.write(full_html)

# 移动端版本：添加微信分享meta标签和更紧凑的移动端优化
mobile_html = full_html.replace(
    '<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">',
    '<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">\n<meta property="og:title" content="苏中区域 ' + REPORT_DATE + ' 销售看板">\n<meta property="og:description" content="乐高苏中区域7家门店每日销售数据看板">'
)

with open(OUTPUT_MOBILE_HTML, 'w', encoding='utf-8') as f:
    f.write(mobile_html)

# 复制一份index.html供云端部署入口
import shutil
shutil.copy2(OUTPUT_HTML, '/Users/a123/WorkBuddy/Claw/outputs/index.html')

print(f"\n✅ 看板生成完成: {OUTPUT_HTML}")
print(f"✅ 移动端看板: {OUTPUT_MOBILE_HTML}")
print(f"✅ JSON数据保存: {OUTPUT_JSON}")

# 打印核心数据供确认
print(f"\n=== 核心数据 ===")
print(f"日销售: ¥{region_day_amt:,.0f}")
print(f"日完成率: {region_day_rate:.1f}%")
print(f"日同比: {region_day_yoy:.1f}%")
print(f"月累计: ¥{region_month_amt:,.0f}")
print(f"月完成率: {region_month_rate:.1f}%")
print(f"月同比: {region_month_yoy:.1f}%")
print(f"\n=== 门店日销售 ===")
for s in STORE_ORDER:
    sd = store_data[s]
    yoy_str = f'{sd["day_yoy_pct"]:.1f}%' if sd['day_yoy_pct'] is not None else 'N/A'
    print(f"  {s}: ¥{sd['day_amt']:,.0f} | 日率{sd['day_rate']:.1f}% | 同比{yoy_str} | 连带{sd['day_jd']:.2f} | 客单¥{sd['day_kdj']:,.0f}")
print(f"\n=== 长尾款 ===")
for s in STORE_ORDER:
    sd = store_data[s]
    print(f"  {s}: 日¥{sd['day_lt_amt']:,.0f}/{sd['day_lt_qty']}件 | 月¥{sd['month_lt_amt']:,.0f}/{sd['month_lt_qty']}件 | 率{sd['lt_rate']:.1f}%")
